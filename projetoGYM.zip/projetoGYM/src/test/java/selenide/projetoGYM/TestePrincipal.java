package selenide.projetoGYM;


import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Configuration;



public class TestePrincipal {
	
	
	@BeforeClass
	void preCondicao() {
		Configuration.startMaximized=true;// Maximizar Navegador
		Configuration.browser="chrome";//Abri navegador chrome
		Configuration.headless=true;// Sem Abrir o navegador
		Configuration.timeout=6000;// 6 sec
	}
	

	@Test
	public void Argentina() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.argentina();
	}
	
	@Test
	public void Brasil() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.brasil();	
	}
	
	@Test
	public void Chile() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.chile();
	}
	
	@Test
	public void Alemanha() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.alemanha();
		
	}
	
	@Test
	public void Espanha() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.espanha();
		
	}
	
	@Test
	public void Italia() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.italia();
	}
	
	@Test
	public void Mexico() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.mexico();
		
	}

	@Test
	public void Portugal() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.portugal();
		
	}
	
	@Test
	public void United_Kingdom() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.united_kingdom();
		
	}
	
	@Test
	void Estados_Unidos() {
		TestePrincipalPages teste = new TestePrincipalPages();
		teste.estados_unidos();
		
	}
}
